export default interface PhotoType {
    id: number;
    size_id: number;
    material_id: number;
    amount: number;
    margin_id: number;
    image: string;
    uploaded: boolean;
}
