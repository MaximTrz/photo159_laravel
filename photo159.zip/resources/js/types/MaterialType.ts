/* eslint-disable @typescript-eslint/no-explicit-any */
export default interface MaterialType {
    id: number;
    name: string;
    [key: string]: any;
}
