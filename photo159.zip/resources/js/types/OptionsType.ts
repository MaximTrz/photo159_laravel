/* eslint-disable @typescript-eslint/no-explicit-any */
export default interface OptionsType {
    id: number;
    name: string;
}
