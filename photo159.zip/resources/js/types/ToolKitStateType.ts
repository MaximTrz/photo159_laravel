import StateType from "./StateType";

export default interface ToolKitStateType {
    toolkitSlice: StateType;
}
