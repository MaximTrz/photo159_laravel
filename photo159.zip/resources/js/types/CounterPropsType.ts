export default interface CounterPropsType {
    amount: number;
    inc: () => void;
    dec: () => void;
}
